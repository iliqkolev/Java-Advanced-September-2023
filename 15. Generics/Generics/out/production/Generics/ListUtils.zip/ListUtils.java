import java.util.Collections;
import java.util.List;

public class ListUtils {
     public static <T extends Comparable<T>> Object getMin(List<T> list){
         ensureNotEmpty(list);
         return Collections.min(list);
     }

    public static <T extends Comparable<T>> Object getMax(List<T> list){
         ensureNotEmpty(list);
        return Collections.max(list);
    }

    private static <T> void ensureNotEmpty(List<T> list){
         if (list.isEmpty()){
             throw new IllegalArgumentException("Requires not empty list");
         }
    }

}
